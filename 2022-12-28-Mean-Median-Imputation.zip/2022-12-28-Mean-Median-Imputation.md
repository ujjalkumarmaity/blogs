---
title: "Matplotlib Demo"
author: "Norah Smith"
date: "5/22/2021"
format: 
  html:
    code-fold: true
jupyter: python3
---

# Mean & Median Imputation
> All about Mean & Median Imputation.

- toc: true
- badges: true
- comments: true
- categories: [jupyter]

**When we can use**
- Data is missing completly random
- No more the 5% of the variable contain missing 

**Mean/Median Imputation Assumptions**
- Data is missing at random

**Mean/Median Imputation Advantage**
- Easy to implement
- Fast way of obtaining in complete dataset

**Mean/Median Imputation Limitation**
- Distortion of the original variable distrubtion & variance
- Higher percentage of NA, the higher distortion

**Improtant Note**
- If variable is **normal distributed then mean imutation is better**
- If variable is **skewed then median imutation is better**
- Imputation value should be **calculated in training set and same value impute in test set**


```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
df = pd.read_csv('titanic.csv')
df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>A/5 21171</td>
      <td>7.2500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>PC 17599</td>
      <td>71.2833</td>
      <td>C85</td>
      <td>C</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    PassengerId      0
    Survived         0
    Pclass           0
    Name             0
    Sex              0
    Age            177
    SibSp            0
    Parch            0
    Ticket           0
    Fare             0
    Cabin          687
    Embarked         2
    dtype: int64




```python
df.isnull().mean()
```




    PassengerId    0.000000
    Survived       0.000000
    Pclass         0.000000
    Name           0.000000
    Sex            0.000000
    Age            0.198653
    SibSp          0.000000
    Parch          0.000000
    Ticket         0.000000
    Fare           0.000000
    Cabin          0.771044
    Embarked       0.002245
    dtype: float64




```python
#mean
print(df.Age.mean())
df['Age_mean_imput'] = df.Age.fillna(df.Age.mean())
```

    29.69911764705882
    


```python
#median
print(df.Age.median())
df['Age_median_imput'] = df.Age.fillna(df.Age.median())
```

    28.0
    


```python
df[['Age','Age_mean_imput','Age_median_imput']].tail(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Age_mean_imput</th>
      <th>Age_median_imput</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>886</th>
      <td>27.0</td>
      <td>27.000000</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>887</th>
      <td>19.0</td>
      <td>19.000000</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>888</th>
      <td>NaN</td>
      <td>29.699118</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>889</th>
      <td>26.0</td>
      <td>26.000000</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>890</th>
      <td>32.0</td>
      <td>32.000000</td>
      <td>32.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[['Age','Age_mean_imput','Age_median_imput']].describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Age_mean_imput</th>
      <th>Age_median_imput</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>714.000000</td>
      <td>891.000000</td>
      <td>891.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>29.699118</td>
      <td>29.699118</td>
      <td>29.361582</td>
    </tr>
    <tr>
      <th>std</th>
      <td>14.526497</td>
      <td>13.002015</td>
      <td>13.019697</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.420000</td>
      <td>0.420000</td>
      <td>0.420000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>20.125000</td>
      <td>22.000000</td>
      <td>22.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>28.000000</td>
      <td>29.699118</td>
      <td>28.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>38.000000</td>
      <td>35.000000</td>
      <td>35.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>80.000000</td>
      <td>80.000000</td>
      <td>80.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Variance
print("variance of original variable",df.Age.var())
print("variance after mean imputation",df.Age_mean_imput.var())
print("variance after median imputation",df.Age_median_imput.var())
```

    variance of original variable 211.0191247463081
    variance after mean imputation 169.05239993721085
    variance after median imputation 169.51249827942328
    


```python
ax = df.Age.plot(kind='kde')
ax.legend()
ax = df.Age_mean_imput.plot(kind='kde',color='green')
ax.legend()
ax = df.Age_median_imput.plot(kind='kde',color='red')
ax.legend()
```




    <matplotlib.legend.Legend at 0x2151dc16340>




    
![png](output_12_1.png)
    


Here we can see distortion of mean/median imputation is higher than original variable

**mean/median imputaion may affect relationship between other variable** 


```python
df[['Fare','Age','Age_mean_imput','Age_median_imput']].cov()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fare</th>
      <th>Age</th>
      <th>Age_mean_imput</th>
      <th>Age_median_imput</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Fare</th>
      <td>2469.436846</td>
      <td>73.849030</td>
      <td>59.162200</td>
      <td>62.556767</td>
    </tr>
    <tr>
      <th>Age</th>
      <td>73.849030</td>
      <td>211.019125</td>
      <td>211.019125</td>
      <td>211.019125</td>
    </tr>
    <tr>
      <th>Age_mean_imput</th>
      <td>59.162200</td>
      <td>211.019125</td>
      <td>169.052400</td>
      <td>169.052400</td>
    </tr>
    <tr>
      <th>Age_median_imput</th>
      <td>62.556767</td>
      <td>211.019125</td>
      <td>169.052400</td>
      <td>169.512498</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[['Age','Age_mean_imput','Age_median_imput']].plot(kind='box')
```




    <AxesSubplot:>




    
![png](output_16_1.png)
    


after mean/median imputation there are more outlier.


```python

```
